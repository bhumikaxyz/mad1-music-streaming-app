class Config(object):
    SECRET_KEY = 'e861bbc266c45fa9c9523ab8e9828209'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///project.sqlite3'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = 'musicapp/static/audios'
    
